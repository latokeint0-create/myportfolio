function readMore() {
  // Navigate to the 'Life as Student' page
  // Use a relative path so it works when hosted under the same folder
  window.location.href = 'student.html';
}
